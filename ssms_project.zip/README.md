# Sweet Shop Management System (SSMS)

A full‑stack application for managing sweets inventory and customer purchases.

## Tech Stack
* **Backend** – Node.js, TypeScript, Express, TypeORM, PostgreSQL
* **Frontend** – React 18, TypeScript, Vite, Tailwind
* **Auth** – JWT
* **Tests** – Jest, Supertest, Vitest

## Setup

```bash
git clone <repo>
cd ssms
yarn install
cp .env.sample .env      # fill database credentials + JWT_SECRET
docker-compose up -d     # start postgres
yarn workspace backend dev   # start backend
yarn workspace frontend dev  # start frontend
```

## AI Usage
Portions of this code were generated with the assistance of an AI coding assistant.

```
Co-authored-by: AI Assistant <ai@example.com>
```
