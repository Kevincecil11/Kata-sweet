import React, { useEffect, useState } from "react";
import axios from "axios";

interface Sweet {
  id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
}

export default function SweetsList() {
  const [sweets, setSweets] = useState<Sweet[]>([]);

  useEffect(() => {
    axios.get("/api/sweets").then(res => setSweets(res.data));
  }, []);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl mb-4">Sweets</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {sweets.map(sw => (
          <div key={sw.id} className="border rounded p-4">
            <h2 className="text-xl">{sw.name}</h2>
            <p>{sw.category}</p>
            <p>${sw.price.toFixed(2)}</p>
            <button
              disabled={sw.quantity === 0}
              className="bg-green-600 text-white px-2 py-1 mt-2 disabled:bg-gray-400"
            >
              {sw.quantity === 0 ? "Out of Stock" : "Buy"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
