import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./Login";
import SweetsList from "./SweetsList";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<SweetsList />} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
