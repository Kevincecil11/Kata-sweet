import { Router } from "express";
import { dataSource } from "../data-source";
import { Sweet } from "../entities/Sweet";
import { authenticate, authorizeAdmin, AuthRequest } from "../middleware/auth";

const router = Router();
const sweetRepo = () => dataSource.getRepository(Sweet);

router.get("/", async (req, res) => {
  const { search, category } = req.query as any;
  const qb = sweetRepo().createQueryBuilder("sweet");
  if (search) qb.andWhere("sweet.name ILIKE :s", { s: `%${search}%` });
  if (category) qb.andWhere("sweet.category = :c", { c: category });
  const sweets = await qb.getMany();
  res.json(sweets);
});

router.post("/", authenticate, authorizeAdmin, async (req, res) => {
  const sweet = sweetRepo().create(req.body);
  await sweetRepo().save(sweet);
  res.status(201).json(sweet);
});

router.put("/:id", authenticate, authorizeAdmin, async (req, res) => {
  const sweet = await sweetRepo().preload({ id: req.params.id, ...req.body });
  if (!sweet) return res.status(404).json({ message: "Not found" });
  await sweetRepo().save(sweet);
  res.json(sweet);
});

router.delete("/:id", authenticate, authorizeAdmin, async (req, res) => {
  const sweet = await sweetRepo().findOne({ where: { id: req.params.id } });
  if (!sweet) return res.status(404).json({ message: "Not found" });
  await sweetRepo().remove(sweet);
  res.status(204).end();
});

export default router;
